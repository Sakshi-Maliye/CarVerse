import math
import pandas as pd

def compute_broker_gamification(events_df, employees_df):
    """Maps events to employees using user_id and calculates XP."""
    # Ensure columns match
    broker_metrics = {}
    
    # We use 'user_id' from events to match 'id' in z_employees.csv
    for _, row in events_df.iterrows():
        uid = row['user_id']
        if pd.isna(uid): continue
            
        if uid not in broker_metrics:
            broker_metrics[uid] = {'xp': 0, 'deals': set()}
            
        bm = broker_metrics[uid]
        bm['deals'].add(row['enquiry_no'])
        
        # Simple point system based on activity
        bm['xp'] += 10 
    
    records = []
    # Merge on 'id' because that is the user_id in z_employees.csv
    for _, emp in employees_df.iterrows():
        uid = emp['id']
        data = broker_metrics.get(uid, {'xp': 0, 'deals': set()})
        
        records.append({
            'emp_id': uid,
            'username': emp['name'],
            'display_name': emp['name'],
            'loc_code': emp['loc_code'],
            'xp': data['xp'],
            'level': int(math.floor((data['xp'] / 100) ** (1 / 1.6))) + 1,
            'trust_score': 90 # Placeholder
        })
        
    return pd.DataFrame(records)