import os
import pandas as pd

# Point to the data directory
DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'data')

def load_data():
    """Loads and merges the broker operational data."""
    events = pd.read_csv(os.path.join(DATA_DIR, 'z_event_log_may_june_2026.csv'))
    employees = pd.read_csv(os.path.join(DATA_DIR, 'z_employees.csv'))
    locations = pd.read_csv(os.path.join(DATA_DIR, 'z_locations.csv'))
    return events, employees, locations

def save_event(enquiry_no, loc_code, emp_id, stage, escalations=0, cancellations=0, deleted_docs=0):
    """Appends a new event state directly to the CSV log."""
    path = os.path.join(DATA_DIR, 'z_event_log_may_june_2026.csv')
    df = pd.read_csv(path)
    
    new_row = pd.DataFrame([{
        'enquiry_no': enquiry_no,
        'loc_code': loc_code,
        'emp_id': emp_id,
        'stage': stage,
        'timestamp': pd.Timestamp.now().strftime('%Y-%m-%d %H:%M:%S'),
        'discount_escalations': escalations,
        'cancellations': cancellations,
        'deleted_docs': deleted_docs,
        'completeness_ratio': 1.0
    }])
    
    df = pd.concat([df, new_row], ignore_index=True)
    df.to_csv(path, index=False)