import os
import pandas as pd
from sklearn.ensemble import IsolationForest
import pickle

DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), 'data')

def train_fraud_detection_model():
    print("Loading Carverse event logs for AI Training...")
    events_df = pd.read_csv(os.path.join(DATA_DIR, 'z_event_log_may_june_2026.csv'))
    
    # We group by 'user_id' because that's the key to the employee
    # We count 'enquiry_no' to see how busy each broker is
    print("Extracting operational features...")
    broker_features = events_df.groupby('user_id').agg({
        'enquiry_no': 'count'
    }).reset_index()
    
    # Rename columns so the AI can read them
    broker_features.columns = ['user_id', 'total_actions']
    
    # Train the AI
    # If a broker has an abnormal number of actions compared to others, 
    # the Isolation Forest will flag them as -1 (anomaly).
    X_train = broker_features[['total_actions']]
    
    ai_model = IsolationForest(n_estimators=100, contamination=0.05, random_state=42)
    ai_model.fit(X_train)
    
    model_path = os.path.join(DATA_DIR, 'fraud_ai_model.pkl')
    with open(model_path, 'wb') as file:
        pickle.dump(ai_model, file)
        
    print(f"✅ AI Training Complete! Model saved to: {model_path}")

if __name__ == "__main__":
    train_fraud_detection_model()